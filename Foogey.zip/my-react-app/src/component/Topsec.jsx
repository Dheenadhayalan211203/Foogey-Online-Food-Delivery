const Topsec=()=>{
    return (
    <>

        <div className="topsec">
        <div className="order">
               <h2>Pick Your</h2>
               <h1>Order</h1>
            </div>
            <div className="container">
                <img src="burger.jpeg"></img>
                <img src="pasta.jpeg"></img>
                <img src="noodles.jpeg"></img>
                <img src="biriyani.jpeg"></img>
            </div>
            <div className="topcrav">
                <span className="topt">T</span><span className="topop">op</span>
                <p className="carving">Carvings</p>
            </div>
            
        </div>

    </>
    )
}

export default Topsec