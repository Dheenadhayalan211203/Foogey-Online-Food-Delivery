const Header=()=>{
    return (
        <>
        <div className="header">
            <div><img className="logo" src="foodlog2.png"></img></div>
           
            <div className="nav-items">
                
                
                <span>Home</span>
                <span>About</span>
                <span>Contact</span>

            </div>
        </div>
     </>
    )
}
export default Header
